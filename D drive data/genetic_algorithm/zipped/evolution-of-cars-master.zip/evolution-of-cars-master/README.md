# Evolution of Cars Using Neural Networks and Genetic Algorithm
A simulation in Unity teaching cars controlled by Neural Networks to complete a racing track optimally using a Genetic Algorithm.
## Video with explanations
[![Evolution of Cars Using Neural Networks and Genetic Algorithm](https://img.youtube.com/vi/BYR9AJdRR90/mqdefault.jpg)](https://www.youtube.com/watch?v=BYR9AJdRR90)
