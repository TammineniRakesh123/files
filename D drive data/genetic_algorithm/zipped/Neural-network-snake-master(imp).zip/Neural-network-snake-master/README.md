# Neural-network-snake
Java program that uses a genetic algorithm to train snakes: https://www.youtube.com/watch?v=BBLJFYr7zB8

I made this project a while ago, initially without intending to publish it someday. Therefore, the style I programmed it in is not the object-oriented style they teach you at school or university. Please don't be mad at me because of it.
However, I tried documenting and refactoring it to make it more readable and understandable.

Have fun trying it out and modifying it. I used a lot of canstants you can tweak easily.

Controls:

a:       pause simulation

b:       resume simulation

c:       show stats

d:       hide stats

space:   watch best snake and its neural network
