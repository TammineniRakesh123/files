# How_to_make_an_evolutionary_tetris_bot
This is the code for the "How to Make an Evolutionary Tetris Bot" by Siraj Raval on Youtube

## Overview

This is the code for [this](https://youtu.be/xLHCMMGuN0Q) video on Youtube by Siraj Raval. We're going to use evolutionary techniques to improve our AI over time. That means through selection, crossover, and mutation, our AI will learn to get to the high score (500) in the shortest amount of time possible. This code is in Javascript for once!

## Dependencies

They all come prepackaged.

## Usage

Just open the .html file in your web browser and the AI will start playing Tetris.

## Credits

The credits for this code go to [idressinc](https://github.com/IdreesInc/). I've merelyc created a wrapper to get people started. 
