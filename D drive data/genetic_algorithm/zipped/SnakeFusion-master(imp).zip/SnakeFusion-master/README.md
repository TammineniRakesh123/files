# SnakeFusion
Using the genetic algorithm and neural networks I trained up 5 snakes who will then fuse to become the ultimate snake, this is how I did it

The program I used to write and run this code was processing https://processing.org/download/

If you get it working some instructions
press Space to just show the current best from  each population
press d to double the mutation rate
press h to halve it 
after you run it some snakes will be saved press 0 to 4 to check them out
to further train the snakes of legend (the saved snakes) press L
to fuse snakes together to create a super snake press f


I hope my commenting makes sense 

Have fun :)
