//****************************************************************************
//**
//**    GameSettings.cpp
//**
//**    Copyright (c) 2010 CarDemo Studios
//**
//**    Author:  Matthew Robbins / Brendan Stemner / Hayley Wallace
//**    Created: 03/2010
//**
//****************************************************************************

#include <iostream>
#include <stdio.h>
#include <stdlib.h>

#include "GameSettings.h"


namespace CarDemo
{
	
}; // End namespace CarDemo.