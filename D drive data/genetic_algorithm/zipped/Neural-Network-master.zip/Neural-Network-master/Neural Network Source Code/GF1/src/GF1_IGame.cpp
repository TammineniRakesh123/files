//****************************************************************************
//**
//**    GF1_IGame.cpp
//**
//**    Copyright (c) 2003 QANTM CMC Australia
//**
//**    Author:  Dale Freya
//**    Created: 21/09/2003
//**
//****************************************************************************
#include "GF1_stdafx.h"
#include "GF1_IGame.h"

   namespace GF1
   {
      // Note: Interface classes must have a virtual non-inline 
      //       destructor and all other members pure virtual.
      IGame::~IGame()
      {
      }

   }  // end namespace GF1

//****************************************************************************
//**
//**    END IMPLEMENTATION
//**
//****************************************************************************
