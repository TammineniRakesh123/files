# Genetic-Algorithm-PathFinder

This is the code I use to make this video:
https://www.youtube.com/watch?v=2Q9bF8Ofyho

Sorry the code is not very clean.
