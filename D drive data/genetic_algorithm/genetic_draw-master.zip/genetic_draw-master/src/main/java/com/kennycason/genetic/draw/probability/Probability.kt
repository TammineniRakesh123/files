package com.kennycason.genetic.draw.probability

/**
 * Created by kenny on 6/1/16.
 */
interface Probability {
    fun next(): Float
}