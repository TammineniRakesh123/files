package com.kennycason.genetic.draw.gene.shape

/**
 * Created by kenny on 5/23/16.
 */
enum class ShapeType {
    ELLIPSE,
    CIRCLE,
    RECTANGLE,
    PIXEL,
    POLYGON
}