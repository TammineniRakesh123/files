# Image Evolution

• Generating an image using simple genetic algorithm. Code written in C# and OpenCVSharp.

• Code written for 1-hr programming contest: Southampton CodeDojo [1], June 2015

• Algorithm inspired by [2], [3]

[1] http://southamptoncodedojo.com/

[2] http://stackoverflow.com/questions/5935059/image-processing-using-genetic-algorithm

[3] http://rogeralsing.com/2008/12/07/genetic-programming-evolution-of-mona-lisa/

• Video Demo:
[![ScreenShot](https://raw.githubusercontent.com/noureldien/ImageEvolution/master/ImageEvolution/Images/snapshot.png)](https://www.youtube.com/watch?v=Tza09kC6Xnc)